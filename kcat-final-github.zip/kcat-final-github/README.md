# Predicting Enzyme Turnover Numbers from Protein and Reaction Features

**Chenchen Xu (徐晨晨), p2625501 — AIDD8122 course project**

This is the final experiment package. Frozen ESM2-650M protein embeddings (1280) and supplied DRFP reaction fingerprints (2048) are concatenated into 3328 features for an XGBoost regressor. The model predicts log10(kcat / s^-1).

## Final results
| Evaluation | n | RMSE | MAE | R² | Within 10-fold |
|---|---:|---:|---:|---:|---:|
| Development 5-fold pooled predictions |3421|0.942338|0.729779|0.365591|73.19%|
| Held-out test |850|0.959956|0.721399|0.357188|74.12%|

Metrics are on the log10 scale. Within 10-fold means absolute log10 error <= 1.
Test enzyme-group bootstrap 95% intervals: R² [0.2623,0.4349], RMSE [0.8724,1.0522]. See original JSON for unrounded values and assumptions.

## Feature ablations (development data only)
| Inputs | RMSE | MAE | R² |
|---|---:|---:|---:|
| Protein + reaction |0.942338|0.729779|0.365591|
| Protein only |0.962229|0.745840|0.338526|
| Reaction only |0.975699|0.752639|0.319877|

## Files
- models/joint_model.json — actual final 1038-tree predictor, not an example.
- results/joint/ — original predictions, protocol, metrics, selected rounds.
- results/ablation/ — both ablations, pooled and fold results.
- results/audit/ — overlap audit, grouped bootstrap, strata and row metadata.
- src/ — portable path adaptations of the training, ablation and audit code.
- provenance/ — unchanged scripts from the completed experiments (server paths retained for provenance).
- scripts/verify_results.py — CPU/standard-library verification of evidence and hashes.
- scripts/predict_features.py — inference from correctly ordered precomputed feature matrix.
- data/README.md, THIRD_PARTY/ — data provenance and attribution.

## Verify without training
Run from this directory:

default command: python scripts/verify_results.py

## Reproduce on Linux GPU 1
Install an appropriate PyTorch GPU build, then: pip install -r requirements.txt
Place the four trusted original dataset files at data/kcat_data/splits/ (see data/README.md).
Download/cache facebook/esm2_t33_650M_UR50D through Hugging Face, or reuse a verified existing cache.

    CUDA_VISIBLE_DEVICES=1 python -u src/train.py
    CUDA_VISIBLE_DEVICES=1 python -u src/ablation.py
    python src/audit.py --out audit_recomputed

Training writes a new joint_run_TIMESTAMP directory. For ablation against a newly trained model set KCAT_JOINT_RUN to that directory; default ablation compares against the archived results/joint predictions. Audit defaults to archived results, not a newly trained run.
KCAT_ROOT may point to an alternate root containing data/ and cache/. The visible physical GPU 1 becomes cuda:0 inside the process.

The archived protocol records XGBoost 3.0.5. requirements.txt is a dependency list, not a full original environment lock. Portable scripts were checked for syntax and archived metrics were recomputed locally; GPU training and legacy pickle loading were not rerun during packaging. Exact regeneration also depends on the encoder revision, cache and numerical environment; the original protocol did not pin an ESM2 checkpoint commit.

## Method and interpretation
The original public TurNuP dataset and its supplied train/test and five CV partitions are used: 3421 training and 850 test rows. The final model uses ESM2 instead of the original predictor's protein representation; dataset provenance is not a claim of model equivalence.
Early stopping used each development validation fold (1500 maximum rounds, patience100). Median selected rounds=1038; the final model was fit on all3421 training rows before test prediction. These CV metrics are model-selection evidence, not nested unbiased evaluation.
Exact sequence and UniProt intersections are zero. 389/850 test rows have a DRFP identity present in training. Exact-sequence separation does not establish low sequence homology; fingerprint identity can include collisions. Do not describe the audit as proof of a random split.
Bootstrap intervals condition on saved predictions and exclude retraining variance. Ablation intervals are exploratory and unadjusted for multiple comparisons. The final study used one training seed (42), not a multi-seed benchmark.
Earlier 24480/2759/2440 experiments used another dataset and are not included in this final package. Their metrics must not be mixed with this benchmark.
