# Attribution
Dataset and predefined folds: TurNuP authors, Zenodo 7849347.
Protein representation: Meta/Facebook ESM2, facebook/esm2_t33_650M_UR50D.
Reaction representation: original dataset's DRFP vectors; DRFP authors.
Regressor: XGBoost authors.
TurNuP_LICENSE.txt preserves the upstream MIT notice retained in the project history; it does not assign that license to datasets, model weights, or all new project code.
The final predictor uses ESM2 + original DRFP concatenation and XGBoost. It is not the original TurNuP predictor. Public data and method origins must remain attributed.
