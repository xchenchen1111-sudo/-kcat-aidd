# 上传说明
1. 将本目录作为最终项目内容。上传文件夹内的 README.md、requirements.txt、src、scripts、models、results、data、provenance、THIRD_PARTY 等内容，保持目录结构。
2. 压缩包用于传输备份；仓库应展示解压后的代码和结果。
3. 如果旧仓库仍有先前 MCKcat 实验，建议归入明确标注的 legacy/，或先备份再替换；不要让旧 README 覆盖本版本。
4. 本包包含实际最终模型 joint_model.json。原始数据和 ESM2大权重不在包内，其来源在 data/README.md。
5. 上传前运行 python scripts/verify_results.py，看到 PASS 再上传。
6. 作者徐晨晨，学号 p2625501。测试850条，R²=0.3572；不能与旧测试2440条的结果混用。

本次只整理本地文件，没有向GitHub提交或删除任何内容。
