# Packaging checks — 2026-11-16
- Recomputed test (850) and development (3421) metrics from CSV: PASS, tolerance1e-6.
- Ablation metrics and joint prediction row/label alignment: PASS.
- Parsed all 10 Python scripts: PASS.
- Loaded actual model with XGBoost3.0.5: PASS, 3328features and1038rounds.
- SHA256 manifest verifies packaged evidence and source files.
- Not rerun: GPU feature extraction/training, raw legacy pickle loading, fresh-environment installation.
- No raw training data, ESM2 weights, feature caches, credentials or old experimental model bundles included.
