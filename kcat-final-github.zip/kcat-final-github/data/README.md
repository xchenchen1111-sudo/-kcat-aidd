# Dataset provenance
Source: TurNuP public dataset, Zenodo record 7849347 (https://zenodo.org/records/7849347).
Use its original files under data/kcat_data/splits/:
- train_df_kcat.pkl: 3421 records
- test_df_kcat.pkl: 850 records
- CV_train_indices.npy and CV_test_indices.npy: 5 provided folds

Original data.zip MD5 recorded during download: c7edbcb34ab906f11303cd1c7d8b0eb9.
Exact extracted-file SHA256 values are preserved in results/joint/protocol.json.
Raw pickles and pretrained ESM2 weights are not redistributed in this package.
Only load trusted original pickle/NumPy object files. Legacy pickles depend on compatible pandas and suds modules; use the original working environment if modern pandas cannot deserialize them. Do not silently skip rows or regenerate splits.
The geomean_kcat column is already the log10 target used in this experiment. Do not log it again.
