"""Predict from exact feature matrix: 1280 ESM2 then 2048 original DRFP."""
import argparse
from pathlib import Path
import numpy as np
import pandas as pd
import xgboost as xgb
p=argparse.ArgumentParser();p.add_argument('--features',required=True,help='NPZ containing X with shape (n,3328)');p.add_argument('--out',required=True);a=p.parse_args()
x=np.load(a.features,allow_pickle=False)['X'].astype(np.float32)
assert x.ndim==2 and x.shape[1]==3328 and np.isfinite(x).all()
assert np.isin(x[:,1280:],[0,1]).all()
m=xgb.Booster();m.load_model(Path(__file__).resolve().parents[1]/'models/joint_model.json');m.set_param({'device':'cpu'})
y=m.predict(xgb.DMatrix(x));pd.DataFrame({'prediction_log10_kcat':y,'prediction_kcat_s_1':np.power(10.,y)}).to_csv(a.out,index=False)
