"""Verify published metrics from saved predictions; standard library only."""
import csv,json,math,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def rows(p):
    with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
def score(rs,key):
    y=[float(r['true']) for r in rs]; p=[float(r[key]) for r in rs]; e=[a-b for a,b in zip(p,y)]; n=len(y); m=sum(y)/n
    return dict(n=n,RMSE=math.sqrt(sum(v*v for v in e)/n),MAE=sum(abs(v) for v in e)/n,R2=1-sum(v*v for v in e)/sum((v-m)**2 for v in y),within_10fold=sum(abs(v)<=1 for v in e)/n)
for name,n in [('test',850),('cv',3421)]:
    rs=rows(ROOT/'results/joint'/f'{name}_predictions.csv');assert len(rs)==n
    assert [int(r['row']) for r in rs]==list(range(n))
    actual=score(rs,'prediction')
    expected=rows(ROOT/'results/joint/test_metrics.csv')[0] if name=='test' else json.loads((ROOT/'results/joint/cv_metrics.json').read_text())
    for k in actual:assert abs(actual[k]-float(expected[k]))<1e-6,(name,k)
    print(name,actual)
a=rows(ROOT/'results/ablation/oof_predictions.csv');j=rows(ROOT/'results/joint/cv_predictions.csv');assert len(a)==3421
for x,y in zip(a,j):assert x['row']==y['row'] and abs(float(x['true'])-float(y['true']))<1e-8 and abs(float(x['joint'])-float(y['prediction']))<1e-6
for r in rows(ROOT/'results/ablation/ablation_summary.csv'):
    for k,v in score(a,r['model']).items():assert abs(v-float(r[k]))<1e-6
for item in json.loads((ROOT/'MANIFEST.json').read_text()):
    f=ROOT/item['path'];assert f.stat().st_size==item['bytes'];assert hashlib.sha256(f.read_bytes()).hexdigest()==item['sha256'],str(f)
model=json.loads((ROOT/'models/joint_model.json').read_text())['learner']
assert int(model['learner_model_param']['num_feature'])==3328
assert len(model['gradient_booster']['model']['trees'])==1038
print('PASS: metrics, row alignment, 3328 features, 1038 trees and file hashes')
