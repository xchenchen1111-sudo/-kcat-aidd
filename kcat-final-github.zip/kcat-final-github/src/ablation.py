"""Two train-only feature ablations on the frozen official five-fold protocol."""
import importlib.util, json, os, sys, time
from pathlib import Path
import numpy as np
import pandas as pd
import xgboost as xgb
from xgboost import XGBRegressor

ROOT=Path(os.environ.get('KCAT_ROOT', str(Path(__file__).resolve().parents[1])))
DATA=ROOT/'data/kcat_data/splits'
PREVIOUS=Path(os.environ.get('KCAT_JOINT_RUN',str(ROOT/'results/joint')))
BENCHMARK=Path(__file__).resolve().with_name('train.py')
PROJECT=Path(__file__).resolve().parent


def main():
    assert os.getenv('CUDA_VISIBLE_DEVICES')=='1'
    sys.path.insert(0,str(PROJECT))
    import optimize
    spec=importlib.util.spec_from_file_location('official_joint_benchmark',BENCHMARK)
    base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);base.optimize=optimize
    protocol=json.loads((PREVIOUS/'protocol.json').read_text())
    for name in ['train_df_kcat.pkl','CV_train_indices.npy','CV_test_indices.npy']:
        assert base.sha(DATA/name)==protocol['sha256'][name], f'Input hash mismatch: {name}'
    assert xgb.__version__==protocol['xgboost'], 'XGBoost version differs from joint run'
    df=pd.read_pickle(DATA/'train_df_kcat.pkl').reset_index(drop=True)
    assert len(df)==3421
    trainfold=np.load(DATA/'CV_train_indices.npy',allow_pickle=True)
    validfold=np.load(DATA/'CV_test_indices.npy',allow_pickle=True)
    assert len(trainfold)==len(validfold)==5
    allidx=set(range(len(df)));seen=[]
    for t,v in zip(trainfold,validfold):
        t=np.asarray(t,dtype=int);v=np.asarray(v,dtype=int)
        assert len(set(t))==len(t) and len(set(v))==len(v)
        assert set(t).isdisjoint(v) and set(t)|set(v)==allidx
        seen.extend(v.tolist())
    assert sorted(seen)==list(range(len(df)))
    old=pd.read_csv(PREVIOUS/'cv_predictions.csv')
    assert np.array_equal(old.row.to_numpy(),np.arange(len(df)))
    y=df.geomean_kcat.to_numpy(float)
    assert np.isfinite(y).all() and np.allclose(y,old.true.to_numpy(),rtol=0,atol=1e-9)
    out=ROOT/('ablation_'+time.strftime('%Y%m%d_%H%M%S'));out.mkdir()
    info={'source_joint_run':str(PREVIOUS),'scope':'3421 official train samples only; no test data read',
        'baseline':'cached joint OOF predictions, prior run with identical folds, parameters and software',
        'experiment':'remove reaction (protein only); remove protein (reaction only)',
        'selection':'each held-out fold used for early stopping; CV scores are exploratory and not unbiased after model selection',
        'input_sha256':{n:base.sha(DATA/n) for n in ['train_df_kcat.pkl','CV_train_indices.npy','CV_test_indices.npy']},
        'joint_predictions_sha256':base.sha(PREVIOUS/'cv_predictions.csv'),
        'joint_script_sha256':base.sha(BENCHMARK),'params':protocol['params'],'xgboost':xgb.__version__}
    (out/'protocol.json').write_text(json.dumps(info,indent=2))
    x,y2=base.features(df,'train');assert np.allclose(y,y2)
    assert x.shape==(len(df),3328)
    params=protocol['params'];predictions={'joint':old.prediction.to_numpy(float)}
    assert np.isfinite(predictions['joint']).all()
    rows=[];previous_folds=pd.read_csv(PREVIOUS/'fold_metrics.csv')
    assert previous_folds.fold.tolist()==list(range(5))
    for i,v in enumerate(validfold):
        v=np.asarray(v,dtype=int);m=base.score(y[v],predictions['joint'][v]); prior=previous_folds.iloc[i]
        assert abs(m['RMSE']-prior.RMSE)<1e-6, 'Prior OOF predictions mismatch'
        rows.append(dict(model='joint',fold=i,rounds=int(prior['rounds']),**m))
    for name,features in [('protein_only',x[:,:1280]),('reaction_only',x[:,1280:])]:
        oof=np.full(len(df),np.nan)
        for i,(t,v) in enumerate(zip(trainfold,validfold)):
            t=np.asarray(t,dtype=int);v=np.asarray(v,dtype=int)
            print('START',name,'fold',i,flush=True)
            model=XGBRegressor(**params,n_estimators=1500,early_stopping_rounds=100)
            model.fit(features[t],y[t],eval_set=[(features[v],y[v])],verbose=200)
            cfg=json.loads(model.get_booster().save_config())
            assert cfg['learner']['generic_param']['device'].startswith('cuda'), 'GPU unavailable'
            p=model.predict(features[v]);assert np.isfinite(p).all();oof[v]=p
            item=dict(model=name,fold=i,rounds=int(model.best_iteration)+1,**base.score(y[v],p))
            rows.append(item);pd.DataFrame(rows).to_csv(out/'fold_metrics.csv',index=False)
            print('FOLD COMPLETE',item,flush=True)
        assert np.isfinite(oof).all();predictions[name]=oof
    results=[dict(model=name,**base.score(y,p)) for name,p in predictions.items()]
    pd.DataFrame(results).to_csv(out/'ablation_summary.csv',index=False)
    pd.DataFrame(dict(row=np.arange(len(df)),true=y,**predictions)).to_csv(out/'oof_predictions.csv',index=False)
    (out/'DONE.txt').write_text('Two train-only ablations completed; no test scoring.\n')
    print(pd.DataFrame(results).to_string(index=False),flush=True)
    print('ABLATION COMPLETE',out,flush=True)

if __name__=='__main__':main()
