import argparse,hashlib,json,re,ast
from pathlib import Path
import numpy as np
import pandas as pd

def save(o,p): p.write_text(json.dumps(o,indent=2,ensure_ascii=False,allow_nan=False),encoding='utf-8')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def ids(v):
    if isinstance(v,(list,tuple,set,np.ndarray)): return sorted(set(z for x in v for z in ids(x)))
    if v is None or (isinstance(v,float) and np.isnan(v)): return []
    s=str(v).strip()
    if s.startswith(('[','(')):
        try:return ids(ast.literal_eval(s))
        except (ValueError,SyntaxError):pass
    return sorted(set(x.strip() for x in re.split(r'[;,\s]+',s) if x.strip() and x.lower() not in ('nan','none')))
def metadata(df):
    out=[]
    for i,(_,r) in enumerate(df.iterrows()):
        seq=''.join(str(r['Sequence']).split()).upper()
        assert seq and seq!='NAN'
        fp=np.asarray(r['DRFP']).reshape(-1)
        assert len(fp)==2048 and np.isin(fp,[0,1]).all()
        out.append(dict(row=i,true=float(r['geomean_kcat']),uids=ids(r['Uniprot IDs']),sequence=hashlib.sha256(seq.encode()).hexdigest(),reaction=hashlib.sha256(fp.astype(np.uint8).tobytes()).hexdigest()))
    return out

def groups(rows):
    # Connected components: any shared UniProt accession OR exact sequence.
    parent=list(range(len(rows)));owners={}
    def find(a):
        while parent[a]!=a:parent[a]=parent[parent[a]];a=parent[a]
        return a
    for i,r in enumerate(rows):
        for key in ['seq:'+r['sequence']]+['uid:'+x for x in r['uids']]:
            if key in owners:parent[find(i)]=find(owners[key])
            else:owners[key]=i
    return np.array([find(i) for i in range(len(rows))])
def align(pred,rows):
    assert len(pred)==len(rows) and pred.row.is_unique
    pred=pred.sort_values('row').reset_index(drop=True)
    assert np.array_equal(pred.row,np.arange(len(rows)))
    assert np.allclose(pred.true,[r['true'] for r in rows],rtol=0,atol=1e-8),'Labels/row ordering mismatch'
    return pred

def metric(y,p,w):
    n=w.sum();m=np.sum(w*y)/n;den=np.sum(w*(y-m)**2)
    return {'RMSE':float(np.sqrt(np.sum(w*(p-y)**2)/n)), 'MAE':float(np.sum(w*np.abs(p-y))/n),'R2':float(1-np.sum(w*(p-y)**2)/den) if den>1e-12 else None}
def bootstrap(df,g,cols,reps):
    _,gi=np.unique(g,return_inverse=True);k=gi.max()+1
    assert k>=2,'Too few groups'
    rng=np.random.default_rng(20261116);y=df.true.to_numpy(); point={c:metric(y,df[c].to_numpy(),np.ones(len(y))) for c in cols}
    draws={c:{m:[] for m in ['RMSE','MAE','R2']} for c in cols}; diffs={c:{m:[] for m in ['RMSE','MAE']} for c in cols[1:]}
    for _ in range(reps):
        w=np.bincount(rng.integers(k,size=k),minlength=k)[gi]
        scores={c:metric(y,df[c].to_numpy(),w) for c in cols}
        for c in cols:
            for m,v in scores[c].items():
                if v is not None:draws[c][m].append(v)
        for c in cols[1:]:
            for m in diffs[c]:diffs[c][m].append(scores[cols[0]][m]-scores[c][m])
    ci=lambda v:dict(CI95=np.quantile(v,[.025,.975]).tolist(),valid_replicates=len(v))
    return dict(groups=int(k),replicates=reps,seed=20261116,method='percentile cluster bootstrap; equal group selection, all rows retained; row-weighted metrics',point=point,intervals={c:{m:ci(v) for m,v in d.items()} for c,d in draws.items()},paired_joint_minus_other={c:{m:ci(v) for m,v in d.items()} for c,d in diffs.items()},limitations='Conditional on fitted predictions; no retraining uncertainty. OOF validation participated in early stopping. Two comparisons are exploratory, unadjusted pointwise intervals.')
def tails(df,out):
    y=df.true.to_numpy();e=df.prediction.to_numpy()-y; edges=[-np.inf,-2,0,2,4,np.inf];rows=[]
    for lo,hi in zip(edges[:-1],edges[1:]):
        m=(y>=lo)&(y<hi);n=int(m.sum())
        rows.append(dict(lower=str(lo),upper=str(hi),n=n,MAE=float(abs(e[m]).mean()) if n else None,bias=float(e[m].mean()) if n else None,within_10fold=float((abs(e[m])<=1).mean()) if n else None))
    pd.DataFrame(rows).to_csv(out/'test_bins.csv',index=False)
    # Standard SVG data plot, no plotting dependency required.
    svg=['<svg xmlns="http://www.w3.org/2000/svg" width="1100" height="600" viewBox="0 0 1100 600"><rect width="1100" height="600" fill="white"/>']
    def txt(x,y,t,size=20):svg.append(f'<text x="{x}" y="{y}" font-family="Arial" font-size="{size}">{t}</text>')
    txt(70,40,'Test error by measured log10(kcat): MAE and signed bias',25)
    for v in range(-3,5):
        yy=330-v*60;svg.append(f'<path d="M70 {yy} H1050" stroke="#dddddd"/>');txt(25,yy+6,str(v))
    for i,r in enumerate(rows):
        x=130+i*185
        for j,(key,col) in enumerate([('MAE','#087F8C'),('bias','#D77A36')]):
            v=r[key] or 0;yy=330-v*60;svg.append(f'<rect x="{x+j*55}" y="{min(330,yy)}" width="45" height="{abs(v)*60}" fill="{col}"/>')
        label=['&lt; -2','[-2, 0)','[0, 2)','[2, 4)','>= 4'][i];txt(x-5,550,label);txt(x-5,580,'n='+str(r['n']),17)
    txt(790,70,'MAE: teal   Bias: orange',18)
    svg.append('</svg>');(out/'test_bins.svg').write_text(''.join(svg),encoding='utf-8')
def main():
    a=argparse.ArgumentParser();a.add_argument('--root',default=str(Path(__file__).resolve().parents[1]));a.add_argument('--out',required=True);a.add_argument('--local-predictions');a.add_argument('--replicates',type=int,default=5000);args=a.parse_args();out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    if args.local_predictions:
        tails(pd.read_csv(args.local_predictions),out);print('LOCAL ERROR BINS COMPLETE; group CI requires source identifiers');return
    root=Path(args.root);data=root/'data/kcat_data/splits';joint=root/'results/joint';abl=root/'results/ablation'
    protocol=json.loads((joint/'protocol.json').read_text())
    for name,expected in protocol['sha256'].items():assert sha(data/name)==expected, 'Source hash mismatch '+name
    frames=[pd.read_pickle(data/n) for n in ['train_df_kcat.pkl','test_df_kcat.pkl']];tr,te=map(metadata,frames)
    save({'train':tr,'test':te},out/'row_metadata.json')
    audit={'train_n':len(tr),'test_n':len(te),'source_sha256':protocol['sha256'],'overlap':{}}
    for key in ['sequence','reaction']:
        trainset={r[key] for r in tr};testset={r[key] for r in te};audit['overlap'][key]=dict(train_unique=len(trainset),test_unique=len(testset),shared_unique=len(trainset&testset),test_rows_seen=sum(r[key] in trainset for r in te),test_row_fraction=sum(r[key] in trainset for r in te)/len(te))
    uidset={u for r in tr for u in r['uids']};tu={u for r in te for u in r['uids']};audit['overlap']['uniprot']=dict(train_unique=len(uidset),test_unique=len(tu),shared_unique=len(uidset&tu),test_rows_any_seen=sum(bool(set(r['uids'])&uidset) for r in te),test_rows_missing=sum(not r['uids'] for r in te))
    pairs={(r['sequence'],r['reaction']) for r in tr};audit['overlap']['sequence_reaction_pair_test_rows']=sum((r['sequence'],r['reaction']) in pairs for r in te)
    upairs={(u,r['reaction']) for r in tr for u in r['uids']};audit['overlap']['uniprot_reaction_pair_test_rows']=sum(any((u,r['reaction']) in upairs for u in r['uids']) for r in te)
    audit['interpretation']='Overlap measures seen-entity coverage, not proof of random splitting. Fingerprint identity can include collisions. Exact sequence audit is not homology clustering.'
    save(audit,out/'split_audit.json')
    test=align(pd.read_csv(joint/'test_predictions.csv'),te);oof=align(pd.read_csv(abl/'oof_predictions.csv'),tr)
    jt=align(pd.read_csv(joint/'cv_predictions.csv'),tr);assert np.allclose(jt.prediction,oof.joint,atol=1e-6)
    tails(test,out)
    save(bootstrap(test,groups(te),['prediction'],args.replicates),out/'test_group_bootstrap.json')
    save(bootstrap(oof,groups(tr),['joint','protein_only','reaction_only'],args.replicates),out/'paired_oof_bootstrap.json')
    folds=np.load(data/'CV_test_indices.npy',allow_pickle=True);evidence=[];seen=[]
    for f,ix in enumerate(folds):
        ix=np.asarray(ix,int);seen.extend(ix.tolist())
        for c in ['joint','protein_only','reaction_only']:evidence.append(dict(fold=f,model=c,n=len(ix),**metric(oof.true.to_numpy()[ix],oof[c].to_numpy()[ix],np.ones(len(ix)))))
    assert sorted(seen)==list(range(len(tr)))
    pd.DataFrame(evidence).to_csv(out/'fold_metrics_recomputed.csv',index=False)
    save({'status':'COMPLETE','numpy':np.__version__,'pandas':pd.__version__},out/'DONE.json');print(json.dumps(audit,indent=2));print('AUDIT AND GROUP BOOTSTRAP COMPLETE',out)
if __name__=='__main__':main()
