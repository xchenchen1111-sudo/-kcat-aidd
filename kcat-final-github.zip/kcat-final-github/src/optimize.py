from protein_encoder import protein_features
def protein(df, cache, device, size):
    assert size == '650M'
    return protein_features(df.sequence.tolist(), cache, device, feature_dim=1280)
