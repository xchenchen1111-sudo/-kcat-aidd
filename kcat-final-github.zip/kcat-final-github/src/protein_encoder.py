from pathlib import Path
import hashlib
import numpy as np
MODEL='hf_esm2_t33_650M_UR50D_v1'
HF_MODEL='facebook/esm2_t33_650M_UR50D'
def protein_features(sequences,cache,device='auto',feature_dim=480):
    import torch
    from transformers import AutoTokenizer, EsmModel
    cache_root=Path(cache)
    cache=cache_root/(MODEL+'_window1022');cache.mkdir(parents=True,exist_ok=True)
    dev=('cuda' if torch.cuda.is_available() else 'cpu') if device=='auto' else device
    model=None;result={}
    for i,seq in enumerate(dict.fromkeys(sequences)):
        p=cache/(hashlib.sha256(seq.encode()).hexdigest()+'.npy')
        legacy=cache_root/MODEL/p.name
        if p.exists(): v=np.load(p,allow_pickle=False)
        elif len(seq)<=1022 and legacy.exists(): v=np.load(legacy,allow_pickle=False)
        else:
            if model is None:
                tokenizer=AutoTokenizer.from_pretrained(HF_MODEL)
                model=EsmModel.from_pretrained(HF_MODEL,add_pooling_layer=False,use_safetensors=True).eval().to(dev)
            v=np.zeros(feature_dim,dtype=np.float64)
            for start in range(0,len(seq),1022):
                part=seq[start:start+1022]
                tokens=tokenizer(part,return_tensors='pt',return_special_tokens_mask=True)
                mask=tokens.pop('special_tokens_mask').to(dev)==0
                tokens={k:v.to(dev) for k,v in tokens.items()}
                mask=mask & tokens['attention_mask'].bool()
                if int(mask.sum())!=len(part): raise ValueError('Tokenizer residue count mismatch')
                with torch.inference_mode():
                    v+=model(**tokens).last_hidden_state[0,mask[0]].float().mean(0).cpu().numpy()*len(part)
            v=(v/len(seq)).astype(np.float32)
            temp=p.with_suffix('.tmp')
            with temp.open('wb') as f:np.save(f,v)
            temp.replace(p)
        if v.shape!=(feature_dim,) or not np.isfinite(v).all():raise ValueError(f'Invalid cache file: {p}')
        result[seq]=v
        if (i+1)%50==0:print(f'Protein features: {i+1} unique sequences',flush=True)
    return np.stack([result[s] for s in sequences])
