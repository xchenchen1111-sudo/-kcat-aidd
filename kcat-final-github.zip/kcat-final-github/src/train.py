"""ESM2/DRFP joint XGBoost on official TurNuP split; test only after CV selection."""
import hashlib,json,os,sys,time
from pathlib import Path
import numpy as np
import pandas as pd
import xgboost as xgb
from xgboost import XGBRegressor


ROOT=Path(os.environ.get('KCAT_ROOT', str(Path(__file__).resolve().parents[1])))
DATA=ROOT/'data/kcat_data/splits'
PROJECT=Path(__file__).resolve().parent
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        while chunk:=f.read(1024*1024):h.update(chunk)
    return h.hexdigest()
def score(y,p):
    e=p-y
    return dict(n=len(y),RMSE=float(np.sqrt(np.mean(e**2))),MAE=float(np.mean(abs(e))),
                R2=float(1-np.sum(e**2)/np.sum((y-y.mean())**2)),within_10fold=float(np.mean(abs(e)<=1)))
def features(df, split):
    assert df.Sequence.map(lambda x:isinstance(x,str) and len(x)>0).all()
    print('ESM2 FEATURES',split,'rows',len(df),'unique',df.Sequence.nunique(),flush=True)
    protein=np.asarray(optimize.protein(df.rename(columns={'Sequence':'sequence'}),
        str(ROOT/'cache'),'cuda','650M'),dtype=np.float32)
    reaction=np.stack([np.asarray(x,dtype=np.float32) for x in df.DRFP])
    assert protein.shape==(len(df),1280) and reaction.shape==(len(df),2048)
    assert np.isfinite(protein).all() and np.isfinite(reaction).all()
    assert np.isin(reaction,[0,1]).all(), 'Official DRFP is not binary'
    y=df.geomean_kcat.to_numpy(float)
    assert np.isfinite(y).all()
    return np.concatenate([protein,reaction],axis=1),y

def main():
    assert os.environ.get('CUDA_VISIBLE_DEVICES')=='1'
    paths=[DATA/n for n in ['train_df_kcat.pkl','test_df_kcat.pkl','CV_train_indices.npy','CV_test_indices.npy']]
    assert all(p.exists() for p in paths)
    # Only official source data, not kcat-trained pretrained weights.
    train=pd.read_pickle(paths[0]).reset_index(drop=True)
    assert len(train)==3421
    trainfold=np.load(paths[2],allow_pickle=True);validfold=np.load(paths[3],allow_pickle=True)
    assert len(trainfold)==len(validfold)==5
    allidx=set(range(len(train)));seen=[]
    for t,v in zip(trainfold,validfold):
        t=np.asarray(t,dtype=int);v=np.asarray(v,dtype=int)
        assert len(set(t))==len(t) and len(set(v))==len(v)
        assert set(t).isdisjoint(v) and set(t)|set(v)==allidx
        seen.extend(v.tolist())
    assert sorted(seen)==list(range(len(train)))
    out=ROOT/('joint_run_'+time.strftime('%Y%m%d_%H%M%S'));out.mkdir()
    params=dict(objective='reg:squarederror',learning_rate=.03,max_depth=6,min_child_weight=5,
        reg_lambda=10,subsample=.8,colsample_bytree=.8,tree_method='hist',device='cuda:0',
        n_jobs=4,random_state=42,eval_metric='rmse')
    protocol={'name':'ESM2-650M + author DRFP joint XGBoost',
        'scope':'author official train/test and 5 CV splits',
        'labels':'geomean_kcat used as log10 target as in official training notebook',
        'selection':'median best iteration from 5 training CV folds; train full training set; evaluate test once',
        'caveat':'not original TurNuP ESM1b-ESP or its optimized parameters; no assumption of no dataset overlap with prior MCKcat experiments',
        'fingerprints':'precomputed author DRFP, shape/binary checked',
        'sha256':{p.name:sha(p) for p in paths},'xgboost':xgb.__version__,'params':params}
    (out/'protocol.json').write_text(json.dumps(protocol,indent=2))
    x,y=features(train,'train')
    print('TRAIN TARGET SUMMARY',dict(min=float(y.min()),max=float(y.max()),mean=float(y.mean())),flush=True)
    oof=np.full(len(y),np.nan);rounds=[];metrics=[]
    for i,(t,v) in enumerate(zip(trainfold,validfold)):
        t=np.asarray(t,dtype=int);v=np.asarray(v,dtype=int)
        print('START OFFICIAL FOLD',i,flush=True)
        m=XGBRegressor(**params,n_estimators=1500,early_stopping_rounds=100)
        m.fit(x[t],y[t],eval_set=[(x[v],y[v])],verbose=200)
        cfg=json.loads(m.get_booster().save_config())
        assert cfg['learner']['generic_param']['device'].startswith('cuda'), 'GPU fallback'
        pred=m.predict(x[v]);oof[v]=pred;rounds.append(int(m.best_iteration)+1)
        metrics.append(dict(fold=i,rounds=rounds[-1],**score(y[v],pred)))
        pd.DataFrame(metrics).to_csv(out/'fold_metrics.csv',index=False)
        print('FOLD COMPLETE',metrics[-1],flush=True)
    assert np.isfinite(oof).all()
    pd.DataFrame({'row':np.arange(len(y)),'true':y,'prediction':oof}).to_csv(out/'cv_predictions.csv',index=False)
    cv=score(y,oof);(out/'cv_metrics.json').write_text(json.dumps(cv,indent=2))
    n=int(np.median(rounds));print('REFIT ALL TRAIN',n,flush=True)
    final=XGBRegressor(**params,n_estimators=n);final.fit(x,y,verbose=False)
    final.get_booster().save_model(out/'joint_model.json')
    (out/'chosen_rounds.json').write_text(json.dumps({'fold_rounds':rounds,'median_rounds':n},indent=2))
    # Test features and labels loaded only after choice and full-training model saved.
    test=pd.read_pickle(paths[1]).reset_index(drop=True);assert len(test)==850
    xt,yt=features(test,'test');p=final.predict(xt)
    assert np.isfinite(p).all()
    metrics=score(yt,p)
    pd.DataFrame([{'model':'joint_esm2_drfp',**metrics}]).to_csv(out/'test_metrics.csv',index=False)
    pd.DataFrame({'row':np.arange(len(yt)),'true':yt,'prediction':p}).to_csv(out/'test_predictions.csv',index=False)
    (out/'DONE.txt').write_text('Official split benchmark completed.\n')
    print('TRAIN CV',cv,flush=True)
    print('OFFICIAL TEST',metrics,flush=True)
    print('BENCHMARK COMPLETE',out,flush=True)

if __name__=='__main__':
    sys.path.insert(0,str(PROJECT))
    import optimize
    main()
